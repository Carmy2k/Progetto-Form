<?php
$con = @new mysqli('localhost:3306', 'root', '', 'ScolarStudyDB') or die("Errore: $conn->connect_error");//versione orientata agli oggetti , new crea un oggetto
