<?php
session_start();
require_once 'getConnection.inc.php';
if(
	$_SERVER['REQUEST_METHOD'] === 'POST' &&
	// isset controlla che sono stati spediti
	isset($_REQUEST['username']) &&
	isset($_REQUEST['secret']) &&
	// empty che non sia vuoto
	// trim controlla che non ho spedito solo spazi
	// real_escape_string evita attachi SQL-injection
	!empty(trim($con->real_escape_string($_REQUEST['username']))) &&
	!empty(trim($con->real_escape_string($_REQUEST['secret'])))
) {
	$username = trim($con->real_escape_string($_REQUEST['username']));
	$secret = trim($con->real_escape_string($_REQUEST['secret']));
	// esegue la query e salva il risultato in rs un ogetto ResultSet
	$rs = $con->query(trim("SELECT id, username FROM Users WHERE username='{$username}' AND secret='$secret';"));
	// controlla che non ci siano errori e riesco ad estrarre almeno una riga
	if ($con->errno === 0 && $rs->num_rows > 0) {  //se il numnero di riga è maggiore di zero
		// estraggo col fetch_assoc() e lo mette nella sessione
		$_SESSION['currentUser'] = $rs->fetch_assoc();
		// chiude la sessione
		$con->close();
		// se le cose vanno bene vai su welcome.php
		header('location: ./welcome.php');
		die;
	}
}
// se le cose vanno male vai su logout.php
header('location: ./logout.php');
die;