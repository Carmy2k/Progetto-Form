<!DOCTYPE html>
<html lang="it">
<head>
	<link rel="stylesheet" href="style.css">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Login</title>
</head>
<body>
<h1>Accedi</h1>
<table>
<form action="./login.php" method="post">
<div>
	<!-- NOME -->
	<label for="username">Username</label><br/>
	<input type="text" name="username" placeholder="username" required/><br/>
	<!-- Password -->
	<label for="password">Password</label><br/>
	<input type="password" name="secret" placeholder="password" required/><br/>
	<div class="tastoinvio">
	<input type="submit" value="Invia" class="btn btn-primary btn-block"/><br/>
	</div>
	<a href="register.php">registrati</a>
</div>
</form>
</table>
</body>
</html>